import React, {useMemo, useState} from "react";
import RenderElement from "../../../base/components/RenderElement/RenderElement";
import {FormButtons} from "../Buttons/Buttons";
import {Form, notification} from "antd";
import {useGetApiCall} from "../../../base/hooks/useGetApiCall";
import {asyncHttpRequest} from "../../../base/services/asyncHttpRequest";
import {useHistory} from "react-router-dom";

const LoginPage = () => {
    const [menuForm] = Form.useForm();
    const history = useHistory();
    const [isUpdating, setIsUpdating] = useState(false);

    // const [showPassword, setShowPassword] = useState(false);
    // const [username, setUsername] = useState("")
    // const [password, setPassword] = useState("")
    // const [captcha, setCaptcha] = useState("")
    // // const [phoneNumber, setPhoneNumber] = useState("")
    //
    // const handleFirstStepEnter = (data) => {
    //     let {username, password, captcha} = data;
    //     setUsername(username);
    //     setPassword(password);
    //     setCaptcha(captcha);
    // };

    const {
        response: captcha,
        status,
        refetchApi,
    } = useGetApiCall({
        endpoint: "/api/captcha/get-captcha",
    });

    async function onSubmit(data) {
        let temp = {};
        for (let [key, value] of Object.entries(data)) {
            if (value) {
                temp[key] = value;
            }
        }
        setIsUpdating(true);
        console.log(temp)
        asyncHttpRequest({
            method: "POST",
            endpoint: "api/auth/login-normal",
            data: {
                ...temp,
            },
        })
            .then((res) => {
                setIsUpdating(false);
                history.push("/dashboard");
                notification.success({
                    message: "ورود با موفقیت انجام شد",
                    placement: "bottomLeft",
                });
            })
            .catch((rej) => {
                notification.error({
                    message: "خطا در انجام عملیات",
                    placement: "bottomLeft",
                });
                setIsUpdating(false);
            });
    }


    const ITEMS = useMemo(
        () => [
            {
                label: "نام کاربری",
                name: "username",
                type: "text",
                rules: [
                    {
                        required: true,
                        message: "وارد کردن رمز عبور الزامی میباشد",
                    },
                ],
            },
            {
                name: "password",
                label: "رمز عبور",
                type: "password",
                size: 12,
                hasFeedback: true,
                rules: [
                    {
                        required: true,
                        message: "وارد کردن رمز عبور الزامی میباشد",
                    },
                ],
            },
            {
                label: "کد",
                name: "captcha",
                type: "text",
                rules: [
                    {
                        required: true,
                        message: "وارد کردن رمز عبور الزامی میباشد",
                    },
                ],
            },

        ],
        []
    );

    return (
        <div
            style={{
                width: "100vw",
                height: "100vh",
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                backgroundImage: "url('/assets/images/bg-1.jpg')",
                backgroundRepeat: "no-repeat",
                backgroundSize: "cover",
                backgroundPosition: "center",
            }}
        >
            <Form form={menuForm} onFinish={onSubmit} className="sh-menu-item">
                <div className="sh-countainer">
                    {ITEMS.map((item) => (
                        <RenderElement searchForm={menuForm} {...item} />
                    ))}
                </div>
                {/*<div className="sh-button">*/}
                {/*    <FormButtons onBack={onBack} isUpdating={isUpdating} />*/}
                {/*</div>*/}
            </Form>
        </div>
    );
};

export default LoginPage;

// async function loginRequest({username, password}) {
async function loginRequest({username, password, captcha}) {
    var myHeaders = new Headers();
    // myHeaders.append("Authorization", "Bearer");
    // myHeaders.append("Content-Type", "application/x-www-form-urlencoded");
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Accept", "application/json, text/plain, */*");
    myHeaders.append("Accept-Language", "fa");

    var requestOptions = {
        method: "POST",
        headers: myHeaders,
        withCredentials: true,
        credentials: "include",
        body: JSON.stringify({
            username: username ?? "",
            password: password ?? "",
            captcha: captcha ?? "",
        }),
        redirect: "follow",
    };

    return fetch("http://localhost:8000/api/auth/login-send-massage", requestOptions)
        // .then((response) => response.text())
        .then((response) => response.text())
        .then((result) => {
            console.log(result);
            // debugger;
            try {
                if (result && JSON.parse(result)) {
                    return JSON.parse(result);
                }
            } catch (err) {
                throw "Error in login";
            }
            return JSON.parse(result);
        })
        .catch((error) => console.log("error", error));
}
