## سیستم فرانت اند سامانه جامع

**سیستم جامع**
شامل چندین زیر بخش میباشد

---

1.  احراز هویت کاربر بااتصال به احراز هویت مرکزی
2.  نمایش سامانه های مختلف براساس دسترسی های کاربر

<br />
<br />

## Comprehensive System - FrontEnd

**Comprehensive System**
There are different parts

---

1. User authentication with keycloak server
2. Show different systems according to user accessibility

---

**Systems**
ManageSystems => Add new Sub system, edit and delete roles in system

---

<br />

**ساختار پروژه**

<br />

1. تمام برنچ ها از برنج base باید ایجاد شوند.
2. هر برنچ مربوط به یک پروژه جداگانه میباشد.
3. تمامی برنچ ها پس از نهایی شدن با برنچ develope مرج میشوند. برنج develope حاوی تمام زیر سیستم ها میباشد و به صورت مستقیم نمیتوان روی آن تغییرات اعمال کرد و حتما باید مرج ریکویست انجام شود.
4. محصول نهایی و خروجی پروژه داخل برنچ main ذخیره میشود که از develope باید روی آن مرج ریکویست انجام گیرد
